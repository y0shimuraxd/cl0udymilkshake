import React, { useEffect, useState } from 'react';
import { YMaps, Map, Placemark } from '@pbe/react-yandex-maps';
import api from '../services/api';

const EventMap = () => {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    api.getEvents()
      .then(res => {
        const raw = res.data;
        setEvents(raw.features || raw); // на случай обычного массива
      })
      .catch(err => console.error('Ошибка загрузки мероприятий:', err));
  }, []);

  return (
    <YMaps query={{ apikey: import.meta.env.VITE_YANDEX_MAP_API_KEY }}>
      <Map
        defaultState={{ center: [57.6261, 39.8845], zoom: 12 }}
        width="100%"
        height="500px"
      >
        {events.map((event, i) => {
          const coords = event.geometry?.coordinates || [event.latitude, event.longitude];
          const title = event.properties?.title || event.title;
          const description = event.properties?.description || event.description;

          return (
            <Placemark
              key={i}
              geometry={coords}
              properties={{
                balloonContent: `
                  <div class="liquid-glass-popup">
                    <strong>${title}</strong><br/>
                    ${description}<br/>
                    <em>${event.date || ''} ${event.time || ''}</em>
                  </div>
                `,
              }}
              options={{
                preset: 'islands#blueIcon',
              }}
            />
          );
        })}
      </Map>
    </YMaps>
  );
};

export default EventMap;
